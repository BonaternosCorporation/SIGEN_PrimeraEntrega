sleep 1

function seleccion(){
case $1 in
1)
  alta_usuario=$(zenity --forms \
    --title 'ABM usuarios y grupos' \
    --text ' * Alta de usuario * ' \
    --add-entry "Nombre de usuario : " \
    --add-entry "HOME dir (vacío=default) : " \
    --add-entry "Comentario : " \
    --add-combo 'Shell' \
    --combo-values '/bin/bash|/bin/sh' \
    --add-password "Contraseña : " \
    --add-password "Repita contraseña : ")
  cod=echo $?
  if [ $cod == 0 ] 
  then
    echo 'aceptar'
  else 
    echo cancelar
  fi



  echo '$alta_usuario : ' $alta_usuario
  usuario=$(echo $alta_usuario | cut -f1 -d'|')
  home_dir=$(echo $alta_usuario | cut -f2 -d'|')
  comentario=$(echo $alta_usuario | cut -f3 -d'|')
  interprete=$(echo $alta_usuario | cut -f4 -d'|')
  contr1=$(echo $alta_usuario | cut -f5 -d'|')
  contr2=$(echo $alta_usuario | cut -f6 -d'|')
  echo '$usuario = ' $usuario; echo '$home_dir = ' $home_dir; echo '$comentario = ' $comentario; echo '$interprete = ' $interprete; echo '$contr1 = ' $contr1; echo '$contr2 = ' $contr2

  exit

  user=zenity --entry --width=300 --text "Nombre del usuario" --title "$2"
  cod=echo $?
  if [ $cod == 0 ]
  then
  sudo adduser $user
  if [ "$?" == 1 ]
  then
    zenity --warning --title="AddUser" --text="El usuario $user ya existe"
  else
    echo "creo el usuario $user" >> /tmp/log 
    progress "Creando usuario" $user "$2"
  fi
  elif [ $cod == -1 ] 
  then
    zenity --error --no-wrap --title="Error" --text="Ocurrio un error"
  fi
;;
2)
group=zenity --entry --width=300 --text "Nombre del grupo" --title "$2" 
cod=echo $?
if [ $cod == 0 ] 
then
creargrupo "$group" 
if [ "$?" == 0 ] 
then
progress "Creando grupo" $group "$2"
echo "creo el grupo $group" >> /tmp/log
fi
elif [ $cod == -1 ] 
then
zenity --error --no-wrap --title="Error" --text="Ocurrio un error"
fi
;;
3)
listaUser=cat /etc/passwd | cut -d: -f1 | sort 
user=zenity --list --height=300 --title="Elija un usuario" --column="USER" $listaUser
cod=echo $?
if [ $cod == 0 ]
then
lsgrp=cat /etc/group | cut -d: -f1 | sort
grp=zenity --list --height=300 --title="Elija un grupo" --column="GRUPOS" $lsgrp
sudo usermod -aG $grp $user
zenity --info --no-wrap --title="$2" --text="Añadió a \'$user\' al grupo $grp"
echo "Añadió a $user al grupo $grp" >> /tmp/log
elif [ $cod == -1 ] 
then
zenity --error --no-wrap --title="Error" --text="Ocurrio un error"
fi
;;
4)
listaUser=cat /etc/passwd | cut -d: -f1 | sort
user=zenity --list --height=300 --title="Elija un usuario" --column="USER" $listaUser
cod=echo $?
if [ $cod == 0 ] 
then
lsgrp=cat /etc/group | cut -d: -f1 | sort
grp=zenity --list --height=300 --title="Elija un grupo" --column="GRUPOS" $lsgrp
sudo deluser $user $grp 
zenity --info --no-wrap --title="$2" --text="Eliminó a \'$user\' del grupo $grp"
echo "Eliminó a $user del grupo $grp" >> /tmp/log
elif [ $cod == -1 ] 
then
zenity --error --no-wrap --title="Error" --text="Ocurrio un error"
fi
;;
5)
listaUser=cat /etc/passwd | cut -d: -f1 | sort
user=zenity --list --height=300 --title="Elija una opcion" --column="USER" $listaUser
cod=echo $?
if [ $cod == 0 ]
then
zenity --question --title="deluser" --text="Borrar home de $user?"
if [ $? == 0 ]
then
sudo deluser $user --remove-home
echo "Elimino el usuario $user con su home" >> /tmp/log
progress "Eliminando Usuario" $user "$2"
else
sudo deluser $user
echo "Elimino el usuario $user y no su home" >> /tmp/log
progress "Eliminando Usuario" $user "$2"
fi
elif [ $cod == -1 ] 
then
zenity --error --no-wrap --title="Error" --text="Ocurrio un error"
fi
;;
6)
lsgrp=cat /etc/group | cut -d: -f1 | sort
grp=zenity --list --height=300 --title="Elija un grupo" --column="GRUPOS" $lsgrp
cod=echo $?
if [ $cod == 0 ] 
then
member=cat /etc/group | grep $grp: | cut -d: -f4 | sort
zenity --info --no-wrap --title="$2" --text="El grupo $grp tiene de miembros: $member"
echo "Listó los miembros de $grp" >> /tmp/log
elif [ $cod == -1 ]
then
zenity --error --no-wrap --title="Error" --text="Ocurrio un error"
fi
;;
7)
lsgrp=cat /etc/group | cut -d: -f1 | sort
grp=zenity --list --height=300 --title="Elija un grupo" --column="GRUPOS" $lsgrp
cod=echo $?
if [ $cod == 0 ] 
then
gksudo delgroup $grp
zenity --info --no-wrap --title="$2" --text="El grupo $grp ha sido eliminado"
echo "Elimino el grupo $grp" >> /tmp/log
elif [ $cod == -1 ] 
then
zenity --error --no-wrap --title="Error" --text="Ocurrio un error"
fi
;;

8)
  if [ -e /tmp/log ]
  then
    zenity --text-info \
      --title="LOG" \
      --filename=/tmp/log \
      --editable 2>/tmp/tmp.txt >/tmp/log.out
    cp /tmp/log.out /tmp/log
  fi
  exit
  ;;

esac

}

function main(){
while [ true ]
do
  opcion=`zenity --list --height=400 --width=400 --radiolist \
    --title="Elija una opcion" \
    --column="" --column="Opcion" \
    "FALSE" "1 Alta Usuario" \
    "FALSE" "2 Crear grupo" \
    "FALSE" "3 Añadir usuario/Grupo" \
    "FALSE" "4 Eliminar Usuario/Grupo" \
    "FALSE" "5 Eliminar Usuario" \
    "FALSE" "6 Mostrar usuarios de un grupo" \
    "FALSE" "7 Eliminar grupo" \
    "TRUE"  "8 Salir"`
  res=$? # preservo el codigo de error antes que cambie
  #echo '$opcion = ' $opcion
  #echo '$?      = ' $?
  #echo '$res    = ' $res
  #exit
  if [ "$res" == 1 ] ; then seleccion 8 ; fi
  seleccion echo $opcion | cut -c 1 "$opcion"
done
}
main
echo 'punto no alcanzado nunca (hay exit en la funcion seleccion)' 
function progress(){
(
echo "0" ; sleep 1
echo "# $1" ; sleep 1
echo "25" ; sleep 1
echo "75" ; sleep 1
echo "100" ; sleep 1
echo "# Finalizado"

) |
zenity --progress \
--title="$3" \
--text="" \
--percentage=0 \
--width=300

if [ "$?" = -1 ] ; then
zenity --error \
--text="Suma Abortada."
fi
}
function creargrupo(){

gksudo groupadd $1
if [ "$?" == 9 ]
then
zenity --warning --title="Groupadd" --text="El grupo \'$1\' ya existe"
return 1
else
return 0

fi
}
cat ./contr
contr1=aB1:5678
contr1='aB1$5678'
contr2=abc
contr2=123
contr2='aB1$5678'
if test $contr1 == $contr2
then
  echo iguales
else
  echo desiguales
  exit
fi
largo=$(echo -n $contr1 | wc -c)
echo $largo
if test $largo -lt 8
then
  echo demasiado corto
else
  echo largo correcto
fi


valor=a
valor=1
valor=a1
#if [[ "$valor" =~ ^[0-9]+$ ]]
if [[ "$valor" =~ [0-9]+$ ]]
then
  echo tiene numero
else
  echo no tiene numero
fi
